﻿namespace Opdracht_MusicApp.Models
{
	public class Song
	{
		public string Title { get; set; }
		public int Length { get; set; }
	}
}
