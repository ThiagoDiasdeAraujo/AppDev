﻿namespace WebApp.Models
{
    public class MenuViewModel
    {
        public Menu? Menu { get; set; }
        public List<Menu>? Menus { get; set; }
    }
}
