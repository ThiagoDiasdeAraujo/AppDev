﻿namespace WebApp.Data
{
    public class Gerecht
    {
        public string? Naam { get; set; }
        public double Prijs { get; set; }
        public bool IsVeggie { get; set; }
    }

}
