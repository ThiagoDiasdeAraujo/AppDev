﻿namespace WebApp.Data
{
    public enum Tijdslot
    {
        Ochtend,
        Middag,
        Avond
    }
}
