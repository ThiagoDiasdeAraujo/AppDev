﻿namespace SportStore.Models
{
    public class AddToCartModel
    {
        public int ProductID { get; set; }

        public int Quantity { get; set; }
    }
}
