﻿using DemoFormulier.Models;
using Microsoft.AspNetCore.Mvc;

namespace DemoFormulier.Controllers
{
    public class BookController : Controller
    {
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(BookModel model)
        {
            //bevat model fouten?
            if (ModelState.IsValid)
            {
                //opslaan in database
                return RedirectToAction(nameof(Success)); //POST/REDIRECT/GET-pattern
            }

            //formulier bevat fouten -> tonen formulier opnieuw
            //geven model mee -> invoervelden behouden blijven
            return View(model);
        }

        public IActionResult Success()
        {
            return View();
        }
    }
}
