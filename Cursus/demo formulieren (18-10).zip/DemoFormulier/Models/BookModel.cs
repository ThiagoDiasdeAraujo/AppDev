﻿using System.ComponentModel.DataAnnotations;

namespace DemoFormulier.Models
{
    public class BookModel
    {
        [Required]
        public string? Title { get; set; }
        [Required]
        public string? Author { get; set; }
        [Display(Name = "ISBN-13")]
        [Required]
        [StringLength(13, MinimumLength = 13, ErrorMessage = "The ISBN-field must be 13 characters long")]
        public string? ISBN { get; set; }
        [Required]
        public string? Genre { get; set; }
        [Required]
        public double? Price { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Release Date")]
        [Required]
        public DateTime? ReleaseDate { get; set; }
    }
}
