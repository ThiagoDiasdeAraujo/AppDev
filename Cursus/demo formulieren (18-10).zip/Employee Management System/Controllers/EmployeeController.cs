﻿using Employee_Management_System.Data;
using Employee_Management_System.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Employee_Management_System.Controllers
{
    public class EmployeeController : Controller
    {
        private DepartmentRepository _departmentRepository = new DepartmentRepository();
        private EmployeeRepository _employeeRepository = new EmployeeRepository();

        public IActionResult Create()
        {
            //model aanmaken en meegeven bij GET-request
            //nodig om in formulier de items voor de dropdown-lijst door te sturen naar de view
            CreateEmployeeModel model = new CreateEmployeeModel();
            model.AllDepartments = _departmentRepository.GetAll().Select(x => new SelectListItem(x.Name, x.Id.ToString()));
            return View(model);
        }

        [HttpPost]
        public IActionResult Create(CreateEmployeeModel model)
        {
            if (ModelState.IsValid)
            {
                //converteer Model naar Entity (voor bewaren in database)
                Employee employee = new Employee();
                employee.FirstName = model.FirstName;
                employee.LastName = model.LastName;
                employee.Email = model.Email;
                employee.Password = model.Password;
                employee.BirthDate = model.BirthDate.Value;
                employee.DepartmentId = model.DepartmentId.Value;

                //bewaren in database (m.b.v. repository)
                _employeeRepository.Add(employee);

                return RedirectToAction("Success");
            }

            //lijst met departments gaat verloren na POST-request
            //(wordt niet meegestuurd naar server -> enkel <input>-elementen)
            model.AllDepartments = _departmentRepository.GetAll().Select(x => new SelectListItem(x.Name, x.Id.ToString()));

            return View(model);
        }

        public IActionResult Success()
        {
            return View();
        }
    }

    
}
