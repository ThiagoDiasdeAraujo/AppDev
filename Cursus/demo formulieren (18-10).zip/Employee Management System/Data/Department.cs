﻿namespace Employee_Management_System.Data
{
    public class Department
    {
        public int Id { get; set; }
        public string Name { get; set; }

    }
}
