﻿
using RecipeApi.DTO.Recipe;

namespace RecipeApi.DTO.Category
{
    public class CreateCategoryDTO
    {
        public string Name { get; set; }
    }
}
