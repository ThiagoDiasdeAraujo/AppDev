﻿namespace RecipeApi.Entities.Base
{
    public class BaseEntity
    {
        public int Id { get; set; }
    }
}
